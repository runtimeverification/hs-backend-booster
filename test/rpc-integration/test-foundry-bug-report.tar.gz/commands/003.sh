#!/usr/bin/env bash
set -euxo pipefail
diff -b -s rpc_139845421760672/002_actual.json rpc_139845421760672/002_response.json
