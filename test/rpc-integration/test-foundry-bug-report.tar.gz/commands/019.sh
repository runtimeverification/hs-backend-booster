#!/usr/bin/env bash
set -euxo pipefail
diff -b -s rpc_139845421760672/010_actual.json rpc_139845421760672/010_response.json
