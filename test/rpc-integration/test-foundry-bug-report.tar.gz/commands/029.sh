#!/usr/bin/env bash
set -euxo pipefail
diff -b -s rpc_139845421760672/015_actual.json rpc_139845421760672/015_response.json
