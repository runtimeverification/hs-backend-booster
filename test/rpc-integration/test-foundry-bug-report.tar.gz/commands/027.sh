#!/usr/bin/env bash
set -euxo pipefail
diff -b -s rpc_139845421760672/014_actual.json rpc_139845421760672/014_response.json
