#!/usr/bin/env bash
set -euxo pipefail
diff -b -s rpc_139845421760672/016_actual.json rpc_139845421760672/016_response.json
