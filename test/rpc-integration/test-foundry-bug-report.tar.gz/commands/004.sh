#!/usr/bin/env bash
set -euxo pipefail
cat rpc_139845421760672/003_request.json | nc -Nv localhost 41441 > rpc_139845421760672/003_actual.json
