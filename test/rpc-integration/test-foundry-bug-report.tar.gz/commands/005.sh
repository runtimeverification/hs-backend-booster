#!/usr/bin/env bash
set -euxo pipefail
diff -b -s rpc_139845421760672/003_actual.json rpc_139845421760672/003_response.json
