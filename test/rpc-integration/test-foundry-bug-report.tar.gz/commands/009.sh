#!/usr/bin/env bash
set -euxo pipefail
diff -b -s rpc_139845421760672/005_actual.json rpc_139845421760672/005_response.json
