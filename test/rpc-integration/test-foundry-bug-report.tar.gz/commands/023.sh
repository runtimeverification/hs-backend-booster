#!/usr/bin/env bash
set -euxo pipefail
diff -b -s rpc_139845421760672/012_actual.json rpc_139845421760672/012_response.json
