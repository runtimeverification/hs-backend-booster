#!/usr/bin/env bash
set -euxo pipefail
diff -b -s rpc_139845421760672/007_actual.json rpc_139845421760672/007_response.json
